# LoginAndSignup
This is a login and signup page that is made  in Android Studio

![Alt Text](https://media.giphy.com/media/1QbD2c5QdlNoFTXHB7/giphy.gif)

I've tried to make it with using material design and Java programming, and I would have liked to share it with other people, so I share it with you here :D

I hope it usable for you :)
