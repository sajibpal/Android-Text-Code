package com.example.vicky.androidui.Model

/**
 * Created by VickY on 2018-03-24.
 */
class Request(){

    var username = ""
    var password = ""

}