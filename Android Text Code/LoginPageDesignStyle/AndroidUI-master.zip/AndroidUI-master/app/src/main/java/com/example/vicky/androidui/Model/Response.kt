package com.example.vicky.androidui.Model

/**
 * Created by VickY on 2018-03-24.
 */
class Response() {

    var result = 0
    var message = ""

}